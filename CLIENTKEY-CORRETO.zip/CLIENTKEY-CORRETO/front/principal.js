let abrir_form = document.getElementById("abrir_form")

abrir_form.addEventListener("click", function () {
    let modal_teste = document.getElementById("id01")

    modal_teste.style.display = "block"
})

let close = document.getElementById("close")

close.addEventListener("click", function () {
    let modal_teste = document.getElementById("id01")
    modal_teste.style.display = "none"
})


async function handleSubmit(event) {
    event.preventDefault();

    let nome = document.getElementById("nome").value;
    let cpf = document.getElementById("cpf").value;
    let email = document.getElementById("email").value;
    let telefone = document.getElementById("telefone").value;
    let endereco = document.getElementById("endereco").value;
    let status = document.getElementById("status").value;

    const data = {
        nome,
        cpf,
        email,
        telefone,
        endereco,
        status
    }


    const response = await fetch('http://localhost:3000/api/store/clientes', {
        method: 'POST',
        headers: { "Content-type": "application/json;charset=UTF-8" },
        body: JSON.stringify(data)
    })

    let content = await response.json()

    if (content.success) {

        var card = document.createElement("div");
        card.classList.add("card"); // Adiciona a classe 'card' ao elemento

        // Define o conteúdo HTML do card com os valores capturados do formulário
        card.innerHTML = `
                <h3>${nome}</h3>
                <p>CPF: ${cpf}</p>
                <p>Email: ${email}</p>
                <p>Telefone: ${telefone}</p>
                <p>Endereço: ${endereco}</p>
                <p>Status: ${status}</p>
            `;

        document.querySelector(".interiorbaixo").appendChild(card);

        document.getElementById("myForm").reset();

        let modal_teste = document.getElementById("id01")

        modal_teste.style.display = 'none'
    } else {
        alert("Erro ao cadastrar cliente!");
    }

}



// Adiciona um ouvinte de evento ao formulário para interceptar o envio
// document.getElementById("myForm").addEventListener("submit", function (event) {
//     event.preventDefault(); // Evita o comportamento padrão do envio do formulário

//     // Recupera os valores dos campos do formulário
//     var nome = document.getElementById("nome").value;
//     var cpf = document.getElementById("cpf").value;
//     var email = document.getElementById("email").value;
//     var telefone = document.getElementById("telefone").value;
//     var endereco = document.getElementById("endereco").value;
//     var status = document.getElementById("status").value;

//     // Cria um elemento de card para exibir as informações do cliente antes de enviar a requisição
//     var card = document.createElement("div");
//     card.classList.add("card"); // Adiciona a classe 'card' ao elemento

//     // Define o conteúdo HTML do card com os valores capturados do formulário
//     card.innerHTML = `
//         <h3>${nome}</h3>
//         <p>CPF: ${cpf}</p>
//         <p>Email: ${email}</p>
//         <p>Telefone: ${telefone}</p>
//         <p>Endereço: ${endereco}</p>
//         <p>Status: ${status}</p>
//     `;

//     // Adiciona o card ao contêiner com a classe 'interiorbaixo'
//     document.querySelector(".interiorbaixo").appendChild(card);

//     // Reseta o formulário após o envio
//     document.getElementById("myForm").reset();

//     // Fecha o modal (assumindo que o elemento modal existe e está visível)
//     var modal = document.getElementById('modal');
//     if (modal) {
//         modal.style.display = 'none';
//     }

//     // Envia os dados do formulário para o servidor usando fetch API
//     fetch('http://localhost:3000/add-client', {
//         method: 'POST', // Define o método HTTP como POST
//         headers: {
//             'Content-Type': 'application/json' // Define o cabeçalho para JSON
//         },
//         body: JSON.stringify({ // Converte os dados do formulário em uma string JSON
//             nome: nome,
//             cpf: cpf,
//             email: email,
//             telefone: telefone,
//             endereco: endereco,
//             status: status
//         })
//     })
//     .then(response => response.text()) // Processa a resposta como texto
//     .then(data => {
//         console.log(data); // Exibe a resposta do servidor no console
//     })
//     .catch(error => {
//         console.error('Error:', error); // Exibe erros no console
//         // Adiciona uma mensagem de erro ao card em caso de falha na requisição
//         card.innerHTML += `
//             <p style="color: red;">Falha ao adicionar o cliente ao server! rsrs</p>
//         `;
//     });
// });