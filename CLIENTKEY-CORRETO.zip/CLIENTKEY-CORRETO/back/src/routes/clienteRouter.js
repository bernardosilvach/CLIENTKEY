const {Router} = require('express');

const router = Router();

const {storeClientes} = require('../controller/clientesController');

router.post('/store/clientes', storeClientes);

module.exports = router;